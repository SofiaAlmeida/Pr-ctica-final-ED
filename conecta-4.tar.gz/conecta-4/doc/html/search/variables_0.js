var searchData=
[
  ['base',['base',['../classMando.html#ad914a93d7fb6c085a26d5d70bbb7fecd',1,'Mando']]]
];
