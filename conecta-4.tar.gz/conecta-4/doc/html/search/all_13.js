var searchData=
[
  ['tablero',['Tablero',['../classTablero.html',1,'Tablero'],['../classTablero.html#a5df607d108c0c0a14aa4f393b7f43030',1,'Tablero::tablero()'],['../classTablero.html#ab4912f28f1db392e1dd44ddc98bd4f59',1,'Tablero::Tablero()'],['../classTablero.html#a51ae562c7dee2909d0fa335b8c3eaf71',1,'Tablero::Tablero(const int filas, const int columnas)'],['../classTablero.html#a95ccd1353038a966ad3304ead106c0d4',1,'Tablero::Tablero(const Tablero &amp;t)']]],
  ['tablero_2eh',['tablero.h',['../tablero_8h.html',1,'']]],
  ['turno',['turno',['../classTablero.html#ae460b4a3245da075dd381365abf158bc',1,'Tablero']]]
];
