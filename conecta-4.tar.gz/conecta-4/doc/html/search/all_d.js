var searchData=
[
  ['n_5ffichas_5fganar',['N_FICHAS_GANAR',['../classTablero.html#aa38ed353bef45bd6c5a2e3aa4a897720',1,'Tablero']]],
  ['nodo',['nodo',['../structArbolGeneral_1_1nodo.html',1,'ArbolGeneral']]],
  ['nodo',['Nodo',['../classArbolGeneral.html#a12cc1b74a9095d89bc7334290d332f7a',1,'ArbolGeneral::Nodo()'],['../structArbolGeneral_1_1nodo.html#aa217b530d586a4f7908df98083c697ff',1,'ArbolGeneral::nodo::nodo()'],['../structArbolGeneral_1_1nodo.html#a858436a6f4cf67e88dcea51708871de9',1,'ArbolGeneral::nodo::nodo(const Tbase &amp;elemento)']]],
  ['nulo',['nulo',['../classArbolGeneral_1_1preorden__iterador.html#a41286b60f0285afb9852679acb42c0b6',1,'ArbolGeneral::preorden_iterador::nulo()'],['../classArbolGeneral_1_1reverse__preorden__iterador.html#ae2f6fe815da3cd60b18623dc519166c3',1,'ArbolGeneral::reverse_preorden_iterador::nulo()'],['../classArbolGeneral_1_1inorden__iterador.html#ab4f05a51c5ddba4ca127f2440a3e3963',1,'ArbolGeneral::inorden_iterador::nulo()'],['../classArbolGeneral_1_1postorden__iterador.html#a68390390c83bf6e26d9ea74d547f1b2c',1,'ArbolGeneral::postorden_iterador::nulo()']]]
];
