var searchData=
[
  ['tablero',['Tablero',['../classTablero.html#ab4912f28f1db392e1dd44ddc98bd4f59',1,'Tablero::Tablero()'],['../classTablero.html#a51ae562c7dee2909d0fa335b8c3eaf71',1,'Tablero::Tablero(const int filas, const int columnas)'],['../classTablero.html#a95ccd1353038a966ad3304ead106c0d4',1,'Tablero::Tablero(const Tablero &amp;t)']]]
];
